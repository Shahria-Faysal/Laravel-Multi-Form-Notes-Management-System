<?php $__env->startSection('content'); ?>
    <div class="container mb-2 d-flex justify-content-between">
        <a href="/" class="btn btn-primary">
            Add New Notes
        </a>
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                Take Database Backup
            </button>

            <ul class="dropdown-menu">

                <li>
                    <form method="POST" action="<?php echo e(route('notes.backup')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="instant">
                        <button class="dropdown-item">Instant</button>
                    </form>
                </li>

                <li>
                    <form method="POST" action="<?php echo e(route('notes.backup')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="1min">
                        <button class="dropdown-item">Every 1 min</button>
                    </form>
                </li>

                <li>
                    <form method="POST" action="<?php echo e(route('notes.backup')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="5min">
                        <button class="dropdown-item">Every 5 min</button>
                    </form>
                </li>

            </ul>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div>
                <div class="card">
                    <div class="card-header">Manage Users</div>
                    <div class="card-body">
                        <?php echo e($notesDataTable->table()); ?>

                        <?php echo e($TrashTable->table()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo e($notesDataTable->scripts(attributes: ['type' => 'module'])); ?>

    <?php echo e($TrashTable->scripts(attributes: ['type' => 'module'])); ?>


    <script type="module">
        document.addEventListener("DOMContentLoaded", function () {
            const table = window.LaravelDataTables['notes-table'];
            const trashTable = window.LaravelDataTables['trash-table'];

            function reloadBoth() {
                table.ajax.reload(null, false);
                trashTable.ajax.reload(null, false);
            }
            const editableColumns = [1, 2];
            const ColumnsNames = ['id', 'title', 'note'];
            let currentRow = null;

            function makeEditable(row) {
                row.find('td').each((i, td) => {
                    if (editableColumns.includes(i)) {
                        const val = $(td).text().trim();
                        $(td).html(`<input type="text" class="form-control editable-input" value="${val}">`);
                    }
                })
            }

            function resetRow(row) {
                row.find('td').each((i, td) => {
                    if (editableColumns.includes(i)) {
                        const val = $(td).find('input').val();
                        $(td).text(val);
                    }
                });
                const userId = row.find('.btn-update').data('id');
                row.find('td:last').html(`<button class="btn btn-primary btn-sm edit-user" data-id="${userId}">Edit</button>
                                                <button class="btn btn-danger btn-sm delete-user" data-id="${userId}">Delete</button>
                                                `);
            }

            $('table').on('click', '.edit-user', function () {
                const row = $(this).closest('tr');
                if (currentRow && !currentRow.is(row)) resetRow(currentRow);
                makeEditable(row);
                currentRow = row;

                const userId = $(this).data('id');
                row.find('td:last').html(`
                                                <button class="btn btn-success btn-sm btn-update" data-id="${userId}">Update</button>
                                                <button class="btn btn-danger btn-sm delete-user" data-id="${userId}">Delete</button>
                                            `);

                $('table').on('click', '.btn-update', function () {
                    const userId = $(this).data('id');
                    const row = $(this).closest('tr');
                    const data = {};
                    row.find('td').each((i, td) => {
                        if (editableColumns.includes(i)) {
                            data[ColumnsNames[i]] = $(td).find('input').val();
                        }
                    });

                    $.ajax({
                        url: "<?php echo e(route('notes.update', ':id')); ?>".replace(':id', userId),
                        type: 'PUT',
                        data: { ...data, _token: '<?php echo e(csrf_token()); ?>' },
                        success: res => {
                            if (res.status === 'success') reloadBoth();
                            else alert(res.message);
                        },
                        error: () => alert('Update Failed')
                    });
                });
            });

            $('table').on('click', '.delete-user', function () {
                const userId = $(this).data('id');
                if (!userId) return;
                if (!confirm('Are you sure?')) return;

                $.ajax({
                    url: "<?php echo e(route('notes.destroy', ':id')); ?>".replace(':id', userId),
                    type: 'DELETE',
                    data: { _token: '<?php echo e(csrf_token()); ?>' },
                    success: res => {
                        if (res.status === 'success') reloadBoth();
                        else alert(res.message);
                    },
                    error: () => alert('Delete Failed')
                });
            });

            $('#trash-table').on('click', '.force-delete', function () {
                const userId = $(this).data('id');
                if (!userId) return;
                if (!confirm('Delete permanently?')) return;

                $.ajax({
                    url: "<?php echo e(route('notes.force-delete', ':id')); ?>".replace(':id', userId),
                    type: 'DELETE',
                    data: { _token: '<?php echo e(csrf_token()); ?>' },
                    success: res => {
                        if (res.status === 'success') reloadBoth();
                        else alert(res.message);
                    },
                    error: () => alert('Delete Failed')
                });
            });

            $('#trash-table').on('click', '.restore-user', function () {
                const userId = $(this).data('id');
                if (!userId) return;
                if (!confirm('Restore?')) return;

                $.ajax({
                    url: "<?php echo e(route('notes.restore', ':id')); ?>".replace(':id', userId),
                    type: 'POST',
                    data: { _token: '<?php echo e(csrf_token()); ?>' },
                    success: res => {
                        if (res.status === 'success') reloadBoth();
                        else alert(res.message);
                    },
                    error: () => alert('Restore Failed')
                });
            });

        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROGRAMMING\Projects\laravel\bulk-form\resources\views/home.blade.php ENDPATH**/ ?>