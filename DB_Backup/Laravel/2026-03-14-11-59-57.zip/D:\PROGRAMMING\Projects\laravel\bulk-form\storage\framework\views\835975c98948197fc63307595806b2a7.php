<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\PROGRAMMING\Projects\laravel\bulk-form\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>