-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: bulk_form
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `status` enum('success','failed') NOT NULL,
  `interval` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('laravel-cache-illuminate:queue:restart','i:1773438566;',2088798566);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000001_create_cache_table',1),(2,'0001_01_01_000002_create_jobs_table',1),(3,'2014_10_12_100000_create_password_resets_table',1),(4,'2026_02_25_184022_create_notes_table',1),(5,'2026_02_26_134433_add_soft_delete_to_notes_table',1),(6,'2026_03_02_051500_create_notifications_table',1),(7,'2026_03_12_142341_create_users_table',1),(8,'2026_03_12_174021_add_user_id_to_notes_table',1),(9,'2026_03_14_111936_create_db_backup_logs_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notes_user_id_foreign` (`user_id`),
  CONSTRAINT `notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,'test1','1','2026-03-13 08:28:41','2026-03-13 08:28:41',NULL,1),(2,'test2','2','2026-03-13 08:28:53','2026-03-13 08:28:53',NULL,1),(3,'test3','3','2026-03-13 08:28:55','2026-03-13 08:31:12','2026-03-13 08:31:12',1),(4,'nigger','ginger','2026-03-13 08:30:47','2026-03-13 08:30:47',NULL,2),(5,'vav','asdcadc','2026-03-13 08:58:26','2026-03-13 08:58:26',NULL,5),(6,'fardin','123','2026-03-13 09:19:36','2026-03-13 09:19:36',NULL,NULL),(7,'ggg','gg','2026-03-13 09:20:51','2026-03-13 09:20:51',NULL,NULL),(8,'frass','as','2026-03-13 09:25:39','2026-03-13 09:25:39',NULL,NULL),(9,'rinh','adc','2026-03-13 09:26:33','2026-03-13 09:26:33',NULL,NULL),(10,'werg','ger','2026-03-13 09:27:00','2026-03-13 09:27:00',NULL,NULL),(11,'dfvcdc','adc','2026-03-13 09:27:33','2026-03-13 09:27:33',NULL,NULL),(12,'nigga','nnn','2026-03-13 09:30:48','2026-03-13 09:30:48',NULL,NULL),(13,'dccawsc','awc','2026-03-13 09:33:15','2026-03-13 09:33:15',NULL,NULL),(14,'erfcscxa','asdc','2026-03-13 09:34:21','2026-03-13 09:34:21',NULL,NULL),(15,'wefdqwe','asdc','2026-03-13 09:42:38','2026-03-13 09:42:38',NULL,NULL),(16,'erfwrf','dfc','2026-03-13 09:50:14','2026-03-13 09:50:14',NULL,5),(17,'scedqawc','awscd','2026-03-13 09:53:02','2026-03-13 09:53:02',NULL,5),(18,'sacasdcasdc','asdc','2026-03-13 10:05:26','2026-03-13 10:05:26',NULL,5),(19,'cdasc','ascd','2026-03-13 10:05:40','2026-03-13 10:05:40',NULL,5),(20,'asdcasc','sdc','2026-03-13 10:05:49','2026-03-13 10:05:49',NULL,5),(21,'ewf','acawsc','2026-03-13 10:08:15','2026-03-13 10:08:15',NULL,5),(22,'qwq','qwqw','2026-03-13 10:08:20','2026-03-13 10:08:20',NULL,5),(23,'ASXzax','azx','2026-03-13 10:09:11','2026-03-13 10:09:11',NULL,5),(24,'ASXax','sax','2026-03-13 10:09:23','2026-03-13 10:09:23',NULL,5),(25,'wqdeq','qwd','2026-03-13 10:10:26','2026-03-13 10:10:26',NULL,5),(26,'asdcascd','asc','2026-03-13 10:12:10','2026-03-13 10:12:10',NULL,5),(27,'sac','sc','2026-03-13 10:13:14','2026-03-13 10:13:14',NULL,5),(28,'wxasxc','ac','2026-03-13 10:14:30','2026-03-13 10:14:30',NULL,5),(29,'wsxax','sac','2026-03-13 10:17:46','2026-03-13 10:17:46',NULL,5),(30,'AScsadc','asxc','2026-03-13 10:19:07','2026-03-13 10:19:07',NULL,5),(31,'ggg','gg','2026-03-13 14:31:42','2026-03-13 14:31:42',NULL,1),(32,'vvvv','vv','2026-03-13 14:35:35','2026-03-13 14:35:35',NULL,1),(33,'bbbbbbbbbb','bb','2026-03-13 14:39:03','2026-03-13 14:39:03',NULL,1),(34,'acdaad','ac','2026-03-13 14:45:39','2026-03-13 14:45:39',NULL,1),(35,'werv','wer','2026-03-13 14:51:05','2026-03-13 14:51:05',NULL,1),(36,'udrgfved','sv','2026-03-13 14:53:35','2026-03-13 14:53:35',NULL,1),(37,'accccc','aw','2026-03-13 14:55:21','2026-03-13 14:55:21',NULL,1),(38,'svfsa c','asdc','2026-03-13 14:56:28','2026-03-13 14:56:28',NULL,1),(39,'cwasdc','sdac','2026-03-13 15:06:15','2026-03-13 15:06:15',NULL,1),(40,'ttttttttttttt','tt','2026-03-13 15:07:25','2026-03-13 15:07:25',NULL,1),(41,'wefcsa','safd','2026-03-13 15:10:49','2026-03-13 15:10:49',NULL,1),(42,'afcasc','sef','2026-03-13 15:11:11','2026-03-13 15:11:11',NULL,1),(43,'afasdc','wef','2026-03-13 15:15:18','2026-03-13 15:15:18',NULL,1),(44,'vcsdv','sd','2026-03-13 15:32:22','2026-03-13 15:32:22',NULL,1),(45,'sacasc','sacd','2026-03-13 15:32:43','2026-03-13 15:32:43',NULL,1),(46,'csacasc','ac','2026-03-13 15:33:04','2026-03-13 15:33:04',NULL,1),(47,'vdvcefd','erf','2026-03-13 15:36:05','2026-03-13 15:36:05',NULL,1),(48,'wqeqdqw','qwed','2026-03-13 15:44:13','2026-03-13 15:44:13',NULL,1),(49,'fardin','casfd','2026-03-13 15:45:47','2026-03-13 15:45:47',NULL,1),(50,'afacd','sadc','2026-03-13 15:49:36','2026-03-13 15:49:36',NULL,1),(51,'sfdascd','sac','2026-03-13 15:50:59','2026-03-13 15:50:59',NULL,1),(52,'afca','asdc','2026-03-13 15:51:04','2026-03-13 15:51:04',NULL,1),(53,'wefdwec','qef','2026-03-13 15:53:34','2026-03-13 15:53:34',NULL,1),(54,'qwef','wefqwf','2026-03-13 15:53:38','2026-03-13 15:53:38',NULL,1),(55,'fqe','fqe','2026-03-13 15:53:43','2026-03-13 15:53:43',NULL,1),(56,'fvsdfvev','asdcawsc','2026-03-13 15:54:04','2026-03-13 15:54:04',NULL,1),(57,'qwefaawc','wefqwf','2026-03-13 15:54:11','2026-03-13 15:54:11',NULL,1),(58,'fqeacascadc','fqe','2026-03-13 15:54:17','2026-03-13 15:54:17',NULL,1);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('075b1b42-7a9f-4d10-bd29-f3191874726a','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"bbbbbbbbbb\"}',NULL,'2026-03-13 14:39:06','2026-03-13 14:39:06'),('0e463e6a-a897-4d26-80d6-87bb554341cb','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"afasdc\"}',NULL,'2026-03-13 15:15:20','2026-03-13 15:15:20'),('2020343e-1766-4741-8902-67c78c1cea86','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"udrgfved\"}',NULL,'2026-03-13 14:53:37','2026-03-13 14:53:37'),('3504fd3c-0056-410a-ba1f-a0cbabc84260','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"ttttttttttttt\"}',NULL,'2026-03-13 15:07:27','2026-03-13 15:07:27'),('46dbd231-08d1-4254-8f75-01c6d0436944','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"cwasdc\"}',NULL,'2026-03-13 15:06:17','2026-03-13 15:06:17'),('58f4ec34-1c1d-4a9e-b32d-77912748e0fe','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"vvvv\"}',NULL,'2026-03-13 14:35:37','2026-03-13 14:35:37'),('5c48d3d1-812b-4485-895a-73a9cee9a33b','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"wxasxc\"}',NULL,'2026-03-13 10:14:32','2026-03-13 10:14:32'),('6033b6bd-f931-4b28-98b2-88848469de50','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"wefcsa\"}',NULL,'2026-03-13 15:10:52','2026-03-13 15:10:52'),('606b1b6f-a7b3-4e32-acca-4dbeb83c8a0c','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"vdvcefd\"}',NULL,'2026-03-13 15:36:07','2026-03-13 15:36:07'),('6e255633-3e13-45b8-9144-64105822eff0','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"asdcascd\"}',NULL,'2026-03-13 10:12:16','2026-03-13 10:12:16'),('7933d2cd-6970-4d0e-8854-6cf73b60a9b7','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"fardin\"}',NULL,'2026-03-13 15:45:49','2026-03-13 15:45:49'),('7e3c6fe8-f976-470e-8b5a-ebbc26cfdbda','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"wqeqdqw\"}',NULL,'2026-03-13 15:44:16','2026-03-13 15:44:16'),('860fdfda-f1ad-4edb-b111-11ebd8ee9c5a','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"sac\"}',NULL,'2026-03-13 10:13:17','2026-03-13 10:13:17'),('a9221440-c953-4fcc-b90d-0a8b9222a3b5','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"test1\"}',NULL,'2026-03-13 10:21:34','2026-03-13 10:21:34'),('b0169dcc-b5ec-41da-b364-5249a33801fc','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"acdaad\"}',NULL,'2026-03-13 14:45:41','2026-03-13 14:45:41'),('bdd71b60-844b-4010-906e-198ec4cc5562','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"csacasc\"}',NULL,'2026-03-13 15:33:06','2026-03-13 15:33:06'),('c7baf32d-025e-4a5f-86ce-a4e878462555','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"test1\"}',NULL,'2026-03-13 10:20:05','2026-03-13 10:20:05'),('d0018a3e-8493-4478-937c-dfbeb1a75e71','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"svfsa c\"}',NULL,'2026-03-13 14:56:30','2026-03-13 14:56:30'),('d19b7560-fda9-46a0-8f93-267ae7e2e4c3','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"wsxax\"}',NULL,'2026-03-13 10:17:48','2026-03-13 10:17:48'),('d1f883d1-916d-43f5-b93d-2ffddb577b27','App\\Notifications\\PushNote','App\\Models\\User',5,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"AScsadc\"}',NULL,'2026-03-13 10:19:09','2026-03-13 10:19:09'),('d3847fe2-601e-4f7d-8c12-cd7ea576bf47','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"werv\"}',NULL,'2026-03-13 14:51:09','2026-03-13 14:51:09'),('e31d5e48-11c3-499f-aefe-706550bf655e','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"sacasc\"}',NULL,'2026-03-13 15:32:45','2026-03-13 15:32:45'),('eb032be4-6d85-4518-987a-198d3204bf61','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"afcasc\"}',NULL,'2026-03-13 15:11:13','2026-03-13 15:11:13'),('f2dbf5e4-ca97-4f86-8c13-10d055feeec8','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"accccc\"}',NULL,'2026-03-13 14:55:24','2026-03-13 14:55:24'),('f439fde7-764a-44c9-9b8d-337df337f180','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"vcsdv\"}',NULL,'2026-03-13 15:32:27','2026-03-13 15:32:27'),('f7d50cc8-915f-498d-984d-80502e532309','App\\Notifications\\PushNote','App\\Models\\User',1,'{\"message\":\"Your Note Has Been Saved!\",\"Note_Title\":\"ggg\"}',NULL,'2026-03-13 14:31:53','2026-03-13 14:31:53');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Fardin','shahriafaysal1@gmail.com','$2y$12$U1LWl7pptMKQOYFKLRpZI.LU/p7ykszAvDDlyZKsLu0gf3y9io2la',0),(2,'FRASS FW','shahriafaysal2@gmail.com','$2y$12$psUDCK/NpWMZnRNEeFk7leu/whEBk7u.iH/uNGQvywX5jNTzVbvWq',0),(3,'faysal','faysal@gmail.com','$2y$12$iGFFgLeHEPV1WM/A1EiKYu.R7a8LjvXO3191UE6OadTeWH10849u.',0),(5,'Frass','frass@gmail.com','$2y$12$5udSIQYAfQQsuOBRwJz4aO5.XFNKlVt6TmtKLM1FFoj3IbNSNih/e',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-14 17:27:09
