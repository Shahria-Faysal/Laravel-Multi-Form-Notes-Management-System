<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-6 mb-3">
                <h1>Welcome <?php echo e(Auth::user()->name); ?></h1>
                <?php echo e(Auth::user()); ?>

            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->is_admin): ?>
                    <a href="<?php echo e(route('notes.index')); ?>" class="btn btn-primary">Go to All notes</a>
                <?php else: ?>
                    <a href="<?php echo e(route('notes.index')); ?>" class="btn btn-primary">Go to my notes</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Logout</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH D:\PROGRAMMING\Projects\laravel\bulk-form\resources\views/dashboard.blade.php ENDPATH**/ ?>