<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;

class Note extends Model
{
    use HasFactory,SoftDeletes,Notifiable;
    protected $table = 'notes';
    protected $fillable = ['title', 'note','user_id'];
}
