<?php echo e($slot); ?>

<?php /**PATH D:\PROGRAMMING\Projects\laravel\bulk-form\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>