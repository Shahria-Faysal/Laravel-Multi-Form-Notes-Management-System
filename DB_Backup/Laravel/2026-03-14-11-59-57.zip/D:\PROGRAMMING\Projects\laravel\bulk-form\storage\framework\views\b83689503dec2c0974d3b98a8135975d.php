<h2>New Note Added</h2>



<p>Thank you.</p><?php /**PATH D:\PROGRAMMING\Projects\laravel\bulk-form\resources\views/emails/note_added.blade.php ENDPATH**/ ?>